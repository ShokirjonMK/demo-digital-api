<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%attent_reason}}`.
 */
class m221116_061650_create_attent_reason_table extends Migration
{
    /**
     * {@inheritdoc}
     */
   
}
