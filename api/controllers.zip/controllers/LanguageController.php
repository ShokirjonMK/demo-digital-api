<?php

namespace api\controllers;

class LanguageController extends ReferenceController
{
    public $type = 'language';
}