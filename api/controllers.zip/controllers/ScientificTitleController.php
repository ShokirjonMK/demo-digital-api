<?php

namespace api\controllers;

class ScientificTitleController extends ReferenceController
{
    public $type = 'scientific-title';
}