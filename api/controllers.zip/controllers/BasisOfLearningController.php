<?php

namespace api\controllers;

class BasisOfLearningController extends ReferenceController
{
    public $type = 'basis-of-learning';
}