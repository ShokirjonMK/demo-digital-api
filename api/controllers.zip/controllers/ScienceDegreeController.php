<?php

namespace api\controllers;

class ScienceDegreeController extends ReferenceController
{
    public $type = 'science-degree';
}