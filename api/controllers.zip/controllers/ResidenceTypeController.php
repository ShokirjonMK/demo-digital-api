<?php

namespace api\controllers;

class ResidenceTypeController extends ReferenceController
{
    public $type = 'residence-type';
}
