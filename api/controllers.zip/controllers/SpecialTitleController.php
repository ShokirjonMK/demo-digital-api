<?php

namespace api\controllers;

class SpecialTitleController extends ReferenceController
{
    public $type = 'special-title';
}