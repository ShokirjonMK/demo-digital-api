<?php
return [
    'adminEmail' => 'admin@example.com',
    'plagiat_percent_max' => 60,
    'exam_control_ball' => 40,
    'student_attent_access_percent' => 25, // foizda beriladi boshqa joyda 100 ga bo'lib olinadi


    //mspd mip params
    'mspdValues' => array(
        'auth_params' => array(
            'username' => 'mvd-jhd-yhxx',
            'password' => 'sZ4bRj8DP2RuR9ibAQcg',
            'grant_type' => 'password'
        ),
        'basic_auth' => array(
            'EgF2xuaaV4fOB1AWlYJsy3qqmW8a',
            'iS3izP2YOI_um7pHdfHnaDymXs4a',
        ),
        'auth_url' => 'https://iskm.egov.uz:9444',
        'base_url' => 'https://apimgw.egov.uz:8243',
    )
];
