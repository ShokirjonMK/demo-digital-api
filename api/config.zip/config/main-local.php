<?php

$config = [
    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => 'l0A3d69fY1wCrLu0zznRdN4GSj1DuqYM',
        ],
    ],
   /*  'log' => [
        'flushInterval' => 1,
        'traceLevel' => YII_DEBUG ? 3 : 0,
        'targets' => [
            [
                'class' => 'yii\log\EmailTarget',
                'levels' => ['error'],
                'categories' => ['yii\db\*'],
                'message' => [
                    'from' => ['log@example.com'],
                    'to' => ['admin@example.com', 'developer@example.com'],
                    'subject' => 'Database errors at example.com',
                ],
            ],
            [
                'class' => 'yii\log\DbTarget',
                'levels' => ['error', 'warning'],
            ],
        ],
    ], */
];



if (!YII_ENV_TEST) {
    // configuration adjustments for 'dev' environment
    $config['bootstrap'][] = 'debug';
    $config['modules']['debug'] = [
        'class' => 'yii\debug\Module',
    ];

    $config['bootstrap'][] = 'gii';
    $config['modules']['gii'] = [
        'class' => 'yii\gii\Module',
    ];
}

return $config;
